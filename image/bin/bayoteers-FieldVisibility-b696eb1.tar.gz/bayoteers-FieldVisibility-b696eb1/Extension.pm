# -*- Mode: perl; indent-tabs-mode: nil -*-
#
# The contents of this file are subject to the Mozilla Public
# License Version 1.1 (the "License"); you may not use this file
# except in compliance with the License. You may obtain a copy of
# the License at http://www.mozilla.org/MPL/
#
# Software distributed under the License is distributed on an "AS
# IS" basis, WITHOUT WARRANTY OF ANY KIND, either express or
# implied. See the License for the specific language governing
# rights and limitations under the License.
#
# The Original Code is the FieldVisibility Bugzilla Extension.
#
# The Initial Developer of the Original Code is YOUR NAME
# Portions created by the Initial Developer are Copyright (C) 2011 the
# Initial Developer. All Rights Reserved.
#
# Contributor(s):
#   YOUR NAME <YOUR EMAIL ADDRESS>

package Bugzilla::Extension::FieldVisibility;
use strict;
use base qw(Bugzilla::Extension);

# This code for this is in ./extensions/FieldVisibility/lib/Util.pm
use Bugzilla::Extension::FieldVisibility::Util;

our $VERSION = '0.01';

# See the documentation of Bugzilla::Hook ("perldoc Bugzilla::Hook" 
# in the bugzilla directory) for a list of all available hooks.


sub config {
    my ($self, $args) = @_;

    my $config = $args->{config};
    $config->{FieldVisibility} = "Bugzilla::Extension::FieldVisibility::ConfigFieldVisibility";
}

sub config_add_panels {
    my ($self, $args) = @_;

    my $modules = $args->{panel_modules};
    $modules->{FieldVisibility} = "Bugzilla::Extension::FieldVisibility::ConfigFieldVisibility";
}
                        


sub install_update_db {
    my ($self, $args) = @_;

}

__PACKAGE__->NAME;