.. _web_server:

Web Server
##########

Bugzilla requires a web server to run CGI scripts. It supports the following:

.. toctree::
   :maxdepth: 1

   apache
   apache-windows
   iis
